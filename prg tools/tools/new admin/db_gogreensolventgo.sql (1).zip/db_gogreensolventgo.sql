-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2017 at 11:48 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_gogreensolvent`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_abouts`
--

CREATE TABLE IF NOT EXISTS `tbl_abouts` (
  `pk_int_about_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_about_image_path` varchar(50) NOT NULL,
  `vchr_about_image2_path` varchar(50) NOT NULL,
  `text_about_title` text NOT NULL,
  `vchr_abouts_sub_title1` varchar(100) DEFAULT NULL,
  `vchr_abouts_sub_title2` varchar(100) DEFAULT NULL,
  `vchr_abouts_sub_title3` varchar(100) DEFAULT NULL,
  `vchr_abouts_sub_title4` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pk_int_about_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_abouts`
--

INSERT INTO `tbl_abouts` (`pk_int_about_id`, `vchr_about_image_path`, `vchr_about_image2_path`, `text_about_title`, `vchr_abouts_sub_title1`, `vchr_abouts_sub_title2`, `vchr_abouts_sub_title3`, `vchr_abouts_sub_title4`) VALUES
(3, 'about359252fe8f2d55.jpeg', 'about2359252ff88bcbc.jpeg', 'asasa', 'asasas', 'asasazazxz', 'sasa', 'sasas'),
(6, 'about65926c1204a017.jpeg', 'about265926c1204bdb5.jpeg', '<p>asasa test</p>', 'asas test', 'asas tset', 'asas test', 'sasas test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_address`
--

CREATE TABLE IF NOT EXISTS `tbl_address` (
  `pk_int_address_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_address_firm_name` varchar(100) NOT NULL,
  `vchr_address_email` varchar(50) NOT NULL,
  `vchr_address_contact_number` varchar(10) NOT NULL,
  `text_address_address` text NOT NULL,
  `vchr_address_map` varchar(1000) NOT NULL,
  `vchr_address_facebook` varchar(100) NOT NULL,
  `vchr_address_gmail` varchar(100) NOT NULL,
  `vchr_address_twitter` varchar(100) NOT NULL,
  PRIMARY KEY (`pk_int_address_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_address`
--

INSERT INTO `tbl_address` (`pk_int_address_id`, `vchr_address_firm_name`, `vchr_address_email`, `vchr_address_contact_number`, `text_address_address`, `vchr_address_map`, `vchr_address_facebook`, `vchr_address_gmail`, `vchr_address_twitter`) VALUES
(11, '$title', '$email', '$contact', '$address', '$map', '', '', ''),
(13, 'test', 'promubashir@gmail.com', '123', 'test', 'test', 'face', 'gmail', 'tw'),
(14, 'Duplex Solutions', 'duplex@duplex.com', '9633349715', 'Address: Manjeri Malappuram, Manjeri-Thrippanachi Road, Patterkulam, Manjeri, Kerala 676121\r\nasas', '<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15659.793173142101!2d76.121668!3d11.117229!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf603d744833bc21!2sDuplex+Solutions!5e0!3m2!1sen!2sin!4v1495108441636" width="100%" height="800" frameborder="0" style="border:0" allowfullscreen></iframe>', 'facebook', 'gmail', 'twitter'),
(15, 'firm', 'email', 'asasasasa', '', 'map', 'FaceBook', '', 'twitter'),
(16, 'asasasa', 'pro.mubashir@gmail.com', '1213131313', '<p>asasasasas sadadsa asasa</p>', 'sasasasasasasasaasasa', 'aasasas', '', 'sasasas'),
(17, 'asa test', 'ASNs test', '0000000000', '<p>asas testy</p>', 'asas test', 'asas test', '', 'tes test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `pk_int_admin_id` int(13) NOT NULL AUTO_INCREMENT,
  `vchr_admin_name` varchar(10) NOT NULL,
  `vchr_admin_password` varchar(10) NOT NULL,
  PRIMARY KEY (`pk_int_admin_id`),
  UNIQUE KEY `vchr_admin_name` (`vchr_admin_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`pk_int_admin_id`, `vchr_admin_name`, `vchr_admin_password`) VALUES
(1, '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE IF NOT EXISTS `tbl_banner` (
  `pk_int_banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_int_banner_category_id` int(11) NOT NULL,
  `vchr_banner_image_path` varchar(50) NOT NULL,
  `vchr_banner_title` varchar(100) DEFAULT NULL,
  `vchr_banner_sub_title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`pk_int_banner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=104 ;

--
-- Dumping data for table `tbl_banner`
--

INSERT INTO `tbl_banner` (`pk_int_banner_id`, `fk_int_banner_category_id`, `vchr_banner_image_path`, `vchr_banner_title`, `vchr_banner_sub_title`) VALUES
(77, 2, 'projects77.png', '', NULL),
(78, 10, 'silder_image3.jpeg', 'ss  dsds sdsds sdsd sdsdsads   sds s  s s   ', NULL),
(79, 9, 'Logo4.png', '', NULL),
(81, 4, 'events81.png', '', NULL),
(82, 5, 'news82.png', '', NULL),
(83, 6, 'team8.png', '', NULL),
(89, 13, '89.jpeg', 'We are very happy to done', 'Over More than 399+ Projects WorldWide'),
(93, 10, 'silder_image13.jpeg', 'asasas sa a asas  as as asa', 'mub'),
(94, 1, 'about94.jpeg', 'NULL', NULL),
(95, 3, 'services11.png', 'NULL', NULL),
(96, 7, 'photo_gallary12.png', 'NULL', NULL),
(97, 8, 'contact13.png', 'NULL', NULL),
(98, 12, 'video_gallery98.jpeg', 'NULL', NULL),
(99, 10, 'silder_image995927d0f493958.jpeg', 'test', 'tes'),
(101, 11, 'project_silder15.png', 'NULL', 'NULL'),
(102, 1, 'about1659257e4508cbe.jpeg', 'NULL', 'NULL'),
(103, 1, 'about1035927d114d65d1.jpeg', 'NULL', 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner_category`
--

CREATE TABLE IF NOT EXISTS `tbl_banner_category` (
  `pk_int_banner_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_banner_category_title` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_banner_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_banner_category`
--

INSERT INTO `tbl_banner_category` (`pk_int_banner_category_id`, `vchr_banner_category_title`) VALUES
(1, 'about'),
(2, 'projects'),
(3, 'services'),
(4, 'events'),
(5, 'news'),
(6, 'team'),
(7, 'photo gallary'),
(8, 'contact'),
(9, 'Logo'),
(10, 'silder_image'),
(11, 'project silder'),
(12, 'Video Gallery'),
(13, 'Project Abouts');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_certificate`
--

CREATE TABLE IF NOT EXISTS `tbl_certificate` (
  `pk_int_certificate_id` int(12) NOT NULL AUTO_INCREMENT,
  `vchr_certificate_path` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_certificate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_certificate`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_email`
--

CREATE TABLE IF NOT EXISTS `tbl_email` (
  `pk_int_email_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_email_name` varchar(50) NOT NULL,
  `vchr_email_email` varchar(100) NOT NULL,
  `vchr_email_website` varchar(50) NOT NULL,
  `vchr_email_subject` varchar(100) NOT NULL,
  `text_email_message` text NOT NULL,
  PRIMARY KEY (`pk_int_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_email`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE IF NOT EXISTS `tbl_event` (
  `pk_int_event_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_event_date` varchar(10) NOT NULL,
  `vchr_event_detail` varchar(300) NOT NULL,
  `vchr_event_photo_path` varchar(100) NOT NULL,
  `vchr_event_time_start` varchar(10) NOT NULL,
  `vchr_event_time_end` varchar(10) NOT NULL,
  `vchr_event_place` varchar(50) NOT NULL,
  `vchr_event_title` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_event_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`pk_int_event_id`, `vchr_event_date`, `vchr_event_detail`, `vchr_event_photo_path`, `vchr_event_time_start`, `vchr_event_time_end`, `vchr_event_place`, `vchr_event_title`) VALUES
(2, '2017-01-01', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas', 'event2.jpeg', '02:00', '01:00', 'New York U.S.A.', 'Get Clear Environmental System');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery_image`
--

CREATE TABLE IF NOT EXISTS `tbl_gallery_image` (
  `pk_int_gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_gallery_path` varchar(50) NOT NULL,
  `vchr_gallery_title` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_gallery_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_gallery_image`
--

INSERT INTO `tbl_gallery_image` (`pk_int_gallery_id`, `vchr_gallery_path`, `vchr_gallery_title`) VALUES
(3, 'gallery3.jpeg', 'asasas'),
(4, 'gallery2592556bf3c326.jpeg', 'asasa'),
(5, 'gallery3592557d497dd6.jpeg', 'asas'),
(6, 'gallery4592559a3c87ab.jpeg', 'asasas'),
(8, 'gallery5592569410f150.jpeg', 'asasas'),
(9, 'gallery659256a8023034.jpeg', 'asa'),
(10, 'gallery759256a8bf1c0c.jpeg', 'asas'),
(11, 'gallery859256a965e469.jpeg', 'asasa'),
(12, 'gallery959256aa1a4f86.jpeg', 'asasas'),
(13, 'gallery1059256aab4d896.jpeg', 'asasasa'),
(14, 'gallery1159256ab473951.jpeg', 'asasas'),
(15, 'gallery1259256abdb0d59.jpeg', 'asasas'),
(16, 'gallery165926b01472349.jpeg', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery_video`
--

CREATE TABLE IF NOT EXISTS `tbl_gallery_video` (
  `pk_int_video_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_video_path` varchar(500) NOT NULL,
  `vchr_gallery_video_title` varchar(100) NOT NULL,
  PRIMARY KEY (`pk_int_video_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_gallery_video`
--

INSERT INTO `tbl_gallery_video` (`pk_int_video_id`, `vchr_video_path`, `vchr_gallery_video_title`) VALUES
(2, '<iframe src="https://www.youtube.com/embed/ZnuwB35GYMY?ecver=1" frameborder="0" allowfullscreen></iframe>', 'aasa'),
(3, '<iframe src="https://www.youtube.com/embed/cZLYvI-I0Ig?ecver=1" frameborder="0" allowfullscreen></iframe>', 'asas'),
(4, '<iframe src="https://www.youtube.com/embed/mkj1uPHS_SE?ecver=1" frameborder="0" allowfullscreen></iframe>        \r\n\r\n            \r\n\r\n    ', 'sasa111aa'),
(5, '<iframe  src="https://www.youtube.com/embed/zixpms1oo40?ecver=1" frameborder="0" allowfullscreen></iframe>', 'asasas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mission`
--

CREATE TABLE IF NOT EXISTS `tbl_mission` (
  `pk_int_mission_id` int(20) NOT NULL AUTO_INCREMENT,
  `fk_int_category_mission_id` int(20) NOT NULL,
  `text_mission_details` text NOT NULL,
  PRIMARY KEY (`pk_int_mission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_mission`
--

INSERT INTO `tbl_mission` (`pk_int_mission_id`, `fk_int_category_mission_id`, `text_mission_details`) VALUES
(6, 1, 'mubashir'),
(8, 3, 'asasas asas SAASA ASAS Asas SAAS ASAS  ASAS aSA ASASA WAsasaasas sasas'),
(9, 1, 'as a   adads assa  adasdaa   sadad  adad'),
(10, 1, 'asas adad sdad adsas'),
(11, 1, 'Eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.'),
(12, 2, 'Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobi.'),
(13, 3, 'Omnis dolor repellendus. Temporibus autem quibusd et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudian sint et molestiae non recusandae. Itaque earum rerum hic tenetur'),
(14, 1, 'sasas'),
(15, 1, 'asasas'),
(16, 1, 'sas'),
(17, 0, '<p>mubashir</p>'),
(18, 0, '<p>aju</p>'),
(19, 1, '<p>asasasasasaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>'),
(20, 2, '<p>ASASAS</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `pk_int_news_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_news_image_path` varchar(50) NOT NULL,
  `vchr_news_title` varchar(50) NOT NULL,
  `vchr_news_place` varchar(50) NOT NULL,
  `vchr_news_date` varchar(15) NOT NULL,
  `vchr_news_details` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_news_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_news`
--

INSERT INTO `tbl_news` (`pk_int_news_id`, `vchr_news_image_path`, `vchr_news_title`, `vchr_news_place`, `vchr_news_date`, `vchr_news_details`) VALUES
(14, 'news1.jpeg', 'Make Plants Alivet', 'john Luis', '2017-01-01', 'Voluptas assumenda est, omnis dolor repellendus. T'),
(15, 'news2.jpeg', 'Migration of Animals', 'John Luis', '2018-01-01', 'Voluptas assumenda est, omnis dolor repellendus. T'),
(16, 'news16.jpeg', 'Migration of Animals', 'john Luis', '2017-01-30', 'Voluptas assumenda est, omnis dolor repellendus. T'),
(17, 'news175926b550cffb0.jpeg', 'asas', 'asas', '2017-05-17', '<p>asasasasasas</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_our_clients`
--

CREATE TABLE IF NOT EXISTS `tbl_our_clients` (
  `pk_int_client_id` int(12) NOT NULL AUTO_INCREMENT,
  `pk_client_path` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_our_clients`
--

INSERT INTO `tbl_our_clients` (`pk_int_client_id`, `pk_client_path`) VALUES
(21, 'client2.png'),
(22, 'client3.png'),
(25, 'client5.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_priorities`
--

CREATE TABLE IF NOT EXISTS `tbl_priorities` (
  `pk_int_priorities_id` int(15) NOT NULL AUTO_INCREMENT,
  `text_priorities_details` text NOT NULL,
  `vchr_priorities_image_path1` varchar(50) DEFAULT NULL,
  `vchr_priorities_image_path2` varchar(50) DEFAULT NULL,
  `vchr_priorities_image_path3` varchar(50) DEFAULT NULL,
  `vchr_priorities_image_path4` varchar(50) DEFAULT NULL,
  `vchr_priorities_image1_title` varchar(30) NOT NULL,
  `vchr_priorities_image2_title` varchar(30) NOT NULL,
  `vchr_priorities_image3_title` varchar(30) NOT NULL,
  `vchr_priorities_image4_title` varchar(30) NOT NULL,
  PRIMARY KEY (`pk_int_priorities_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_priorities`
--

INSERT INTO `tbl_priorities` (`pk_int_priorities_id`, `text_priorities_details`, `vchr_priorities_image_path1`, `vchr_priorities_image_path2`, `vchr_priorities_image_path3`, `vchr_priorities_image_path4`, `vchr_priorities_image1_title`, `vchr_priorities_image2_title`, `vchr_priorities_image3_title`, `vchr_priorities_image4_title`) VALUES
(20, '<p>ASASASASAS</p>', 'priorities1_159269aaf88ccc.jpeg', 'priorities2_159269aaf8a6fe.jpeg', 'priorities3_159269aaf8c138.jpeg', 'priorities4_159269aaf8d686.jpeg', 'asaSAS', 'asaSAS', 'asaS', 'asASAS'),
(22, '<p>asasas</p>', 'priorities1_25926bf1820cbb.jpeg', 'priorities2_25926bf1822ffe.jpeg', 'priorities3_25926bf18250df.', 'priorities4_25926bf1825e3f.', '', '', '', ''),
(23, '<p>sasasasasasa</p>', 'priorities1_35926c921712cb.', 'priorities2_35926c92171d2a.', 'priorities3_35926c92172dc5.', 'priorities4_35926c92173f20.', 'asas', 'asas', 'asas', 'asas'),
(24, 'asasas', 'priorities1_45927b1b626558.jpeg', 'priorities2_45927b1b627c8e.', 'priorities3_45927b1b6280d3.', 'priorities4_45927b1b6284e1.', 'sas', 'asas', 'sasa', 'asas'),
(25, 'haiSASA', 'priorities1_55927bcf97a149.', 'priorities2_55927bcf97acc6.', 'priorities3_55927bcf97b7da.', 'priorities4_55927bcf97c22c.', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `pk_int_product_id` int(10) NOT NULL AUTO_INCREMENT,
  `vchr_product_image_path` varchar(50) NOT NULL,
  `vchr_product_title` varchar(50) NOT NULL,
  `vchr_product_details` varchar(100) NOT NULL,
  PRIMARY KEY (`pk_int_product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`pk_int_product_id`, `vchr_product_image_path`, `vchr_product_title`, `vchr_product_details`) VALUES
(20, 'service20.jpeg', 'Sustainable Agriculture', 'Temporibus autem quibusdam et aut officiis debitis aut rerum pecessitatibus.'),
(21, 'service21.jpeg', 'Sustainable Agriculture', 'Temporibus autem quibusdam et aut officiis debitis aut rerum pecessitatibus.'),
(27, 'service27.jpeg', 'img Sustainable Agriculture', 'Temporibus autem quibusdam et aut officiis debitis aut rerum pecessitatibus.'),
(28, 'service28.jpeg', 'Sustainable Agriculture', 'Temporibus autem quibusdam et aut officiis debitis aut rerum pecessitatibus.'),
(29, 'service295926a491936c2.jpeg', 'test', '<p>test</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_category`
--

CREATE TABLE IF NOT EXISTS `tbl_product_category` (
  `pk_product_category_id` int(12) NOT NULL AUTO_INCREMENT,
  `vchr_product_category_image_path` varchar(50) NOT NULL,
  `vchr_product_category_title` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_product_category_id`),
  KEY `vchr_product_category_title` (`vchr_product_category_title`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_product_category`
--

INSERT INTO `tbl_product_category` (`pk_product_category_id`, `vchr_product_category_image_path`, `vchr_product_category_title`) VALUES
(1, 'category1.jpeg', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE IF NOT EXISTS `tbl_service` (
  `pk_int_service_id` int(12) NOT NULL AUTO_INCREMENT,
  `vchr_service_path` varchar(50) NOT NULL,
  `vchr_service_title` varchar(50) NOT NULL,
  `vchr_service_details` varchar(200) NOT NULL,
  PRIMARY KEY (`pk_int_service_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_service`
--

INSERT INTO `tbl_service` (`pk_int_service_id`, `vchr_service_path`, `vchr_service_title`, `vchr_service_details`) VALUES
(2, 'service1.png', 'Young Planting', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut pabore dolore.'),
(10, 'service35926a2b36682b.jpeg', 'asas', 'asas'),
(11, 'service45926a2ba96340.jpeg', 'asas', 'asas'),
(12, 'service55926a2c2a4c37.jpeg', 'asas', 'sasas'),
(13, 'service65926a2cc83362.jpeg', 'asasa', 'asasa'),
(14, 'service65926a2dbabf58.jpeg', 'asas', 'asasa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_team`
--

CREATE TABLE IF NOT EXISTS `tbl_team` (
  `pk_int_team_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_team_name` varchar(50) NOT NULL,
  `vchr_team_path` varchar(50) NOT NULL,
  `vchr_team_designation` varchar(20) NOT NULL,
  `vchr_team_facebook_address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pk_int_team_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_team`
--

INSERT INTO `tbl_team` (`pk_int_team_id`, `vchr_team_name`, `vchr_team_path`, `vchr_team_designation`, `vchr_team_facebook_address`) VALUES
(4, 'ANDREW SMITH', 'team4.jpeg', 'Co-ordinator', 'asasas'),
(6, 'mubas', 'team65926b229534cb.jpeg', 'i', 'ii');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_why_choose`
--

CREATE TABLE IF NOT EXISTS `tbl_why_choose` (
  `pk_int_why_choose_id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_category_why_choose_id` int(11) NOT NULL,
  `text_why_choose_details` text NOT NULL,
  PRIMARY KEY (`pk_int_why_choose_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_why_choose`
--

INSERT INTO `tbl_why_choose` (`pk_int_why_choose_id`, `fk_category_why_choose_id`, `text_why_choose_details`) VALUES
(3, 2, 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.'),
(4, 3, 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.'),
(5, 0, 'mubashir'),
(6, 0, 'mubashir'),
(7, 1, '<p>oki</p>'),
(8, 4, 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum at vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia.'),
(9, 2, '<p>sasasas</p>'),
(10, 1, '<p>hai</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_why_choose_photo`
--

CREATE TABLE IF NOT EXISTS `tbl_why_choose_photo` (
  `pk_int_why_choose_photo_id` int(11) NOT NULL AUTO_INCREMENT,
  `vchr_why_choose_photo_path` varchar(50) NOT NULL,
  PRIMARY KEY (`pk_int_why_choose_photo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_why_choose_photo`
--

INSERT INTO `tbl_why_choose_photo` (`pk_int_why_choose_photo_id`, `vchr_why_choose_photo_path`) VALUES
(6, 'about_why_choose65926c3731b5b5.jpeg');
